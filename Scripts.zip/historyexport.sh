USER=whoami
export USER
export HISTTIMEFORMAT="$USER %d/%m/%y %T "
history >> history.log`date +%Y%m%d`
