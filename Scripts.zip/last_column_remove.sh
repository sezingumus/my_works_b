#csv veya xlsx dosyasındaki son kolonu siler
rev $FULLFILENAME | cut -d ";" -f 2-  | rev > $SINEMAFILENAME