#gunluk sinema raporunu mail atan script.
#10 10 * * * /opt/scripts/sendmail.sh #Hergun saat 10:10 da mail atan cronjob
filedir="/home/postgres/biletix_shared_files"
FILENAME="gunluk-sinema-rapor"
DATE=`/bin/date --date="1 days ago" +%Y%m%d`
FULLFILENAME="$filedir/$FILENAME-$DATE.csv"
echo "Gunluk sinema raporu mailde ektedir." | mail -s "Gunluk Sinema Raporu" -r sinema@biletix.com -a $FULLFILENAME  sgumus@biletix.com


