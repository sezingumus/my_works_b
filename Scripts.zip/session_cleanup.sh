find /opt/jboss/server/btx/tmp/sessions/* -mtime +1 -exec rm -fr {} \;
find /tmp/*  -mtime +1 -exec rm -fr  {} \;

find /opt/jboss/server/btx/log/* -mtime +3 -exec rm -fr  {} \;