find /path -mtime +1 -exec rm -fr {} \;
find /path  -mtime +1 -exec rm -fr  {} \;
