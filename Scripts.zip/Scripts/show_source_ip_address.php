#source ip görüntüleyen code
<html>
<head>
    <title>Palpable Coral</title>
</head>
<body>
Your IP address is: < ? php echo $_SERVER['REMOTE_ADDR'] ? >
</body>
</html>