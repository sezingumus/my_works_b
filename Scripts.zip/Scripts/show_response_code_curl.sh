Response code döndüren curl komutu
curl -s -o /dev/null -w "%{http_code}" http://www.a.com

