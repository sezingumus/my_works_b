
filedir="/filepath"
FILENAME="file name"
DATE=`/bin/date --date="1 days ago" +%Y%m%d`
FULLFILENAME="$filedir/$FILENAME-$DATE.csv"
echo "Gunluk raporu mailde ektedir." | mail -s "Gunluk Rapor" -r gonderen@mail.com -a $FULLFILENAME  alici@mail.com


