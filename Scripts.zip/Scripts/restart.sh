killall -9 java 
sleep 3
killall -9 java
/path/startservers.sh
