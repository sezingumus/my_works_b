#Belirli bir ip adresine belirli bir port üzerinden bağlantı olup olmadığını gösteren script
(echo >/dev/tcp/https://code.google.com/archive/p/recaptcha/wikis/FirewallsAndRecaptcha.wiki/{port}) &>/dev/null && echo "open" || echo "close"
(echo >/dev/udp/{host}/{port}) &>/dev/null && echo "open" || echo "close"
